$(document).ready(function() {
    $(".link_1").click(function () {
        $(".container").fadeToggle('fast');
    });
})
$(document).ready(function (){
    $(".noshow").click(function(){
        $(".container").fadeOut('fast');
    });
})